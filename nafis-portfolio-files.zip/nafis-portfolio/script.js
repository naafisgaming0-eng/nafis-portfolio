// Small interaction for the Nafis portfolio.
document.getElementById("year").textContent = new Date().getFullYear();

document.querySelectorAll("nav a").forEach((link) => {
  link.addEventListener("click", () => {
    console.log("Opened section:", link.textContent);
  });
});
