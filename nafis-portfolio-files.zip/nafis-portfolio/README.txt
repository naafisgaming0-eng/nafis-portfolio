NAFIS PERSONAL PORTFOLIO

Files:
- index.html  : website content
- style.css   : website design
- script.js   : small JavaScript interactions

To preview:
Open index.html in a web browser.

To publish with GitHub + Cloudflare Pages:
1. Create a public GitHub repository named nafis-portfolio.
2. Upload all three website files (index.html, style.css, script.js) to the repository root.
3. In Cloudflare Dashboard, open Workers & Pages and create a Pages project.
4. Connect the GitHub repository.
5. Choose Framework preset: None.
6. Leave Build command blank.
7. Set Build output directory to / (or . if the dashboard requires a dot).
8. Deploy.

Before publishing, replace your-email@example.com in index.html with an email address you want visitors to use.
